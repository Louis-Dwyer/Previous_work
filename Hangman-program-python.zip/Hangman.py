#Names: Louis Dwyer [21335163] and Cian Winder [21424916]
#Date: 03/11/21#
from random import randint
import string
play = 0
while play == 0: 
  #This loop is for repeat plays.
  counter = 0
  xlist = []
  dmitri = open("Dmitri.txt", "r")
  counter = len(open("Dmitri.txt").readlines())
  my_word = randint(1,counter)
  #The above code opens the file and selects a random word from within said file .
  def Hangman(filename, word):
    alphabet=list(string.ascii_lowercase)
    #This line is used to define what letters can be entered into the game.
    a = 5
    #The variable "a" is used as a life counter for the game.
    words = dmitri.readlines()
    word = words[my_word]
    lower_word = word.lower()
    for x in lower_word:
      xlist.append(x)
    hidden_list = ['-']*(len(lower_word)-1)
    hidden_string = ''.join(hidden_list)
    print("...........................................................")
    print("Word: ", hidden_string)
    print(xlist[:-1])
    #All of this code is used to create a list of the letters in the mystery word, this makes it easier to adjust for guessed later on.
    wrong_letters = []
    print("________      ")
    print("|      |      ")
    print("|      0      ")
    print("|             ")
    print("|             ")
    print("|             ")
    #This code is just for looks, it displays the noose and stand from the game.
    while a > 0:
      Letter = input("Guess a Letter: ")
      letter = Letter.lower()
      print("...........................................................")
      if letter=="":
        print("Please input a letter")
      found=False
       #this code ensures the person has lives left and asks the user for an input
      for x in alphabet:
        if letter.lower()==x:
          found=True
          break
          #This code ensures the item entered is a letter and not another character
      if letter in lower_word:
          for l, x in enumerate(xlist):
            if x == letter:
              hidden_list[l] = letter
          hidden_string = ''.join(hidden_list)
          print("Word: ", hidden_string)
          if hidden_list == xlist[:-1]:
            print("...........................................................")
            print("Game Over.\nYou win, I guess........")
            break
            #The above code is the heart of the program, this checks if the inputted letter is in the word and if it is, it prints the updated list.
      else:
          wrong_letters.append(letter)
          print("Incorrect Guess!\nGuessed Letters: " ,wrong_letters)
          a -= 1
          print("Lives remaining",a)
      if found is True:
        if a == 5:
          print("________      ")
          print("|      |      ")
          print("|      0      ")
          print("|             ")
          print("|             ")
          print("|             ")
        if a == 4:
          print("________      ")
          print("|      |      ")
          print("|      0      ")
          print("|      |      ")
          print("|             ")
          print("|             ")
          print("Word: ", hidden_string)
        if a == 3:
          print("________      ")
          print("|      |      ")
          print("|      0      ")
          print("|     /|      ")
          print("|             ")
          print("|             ")
          print("Word: ", hidden_string)
        if a == 2:
          print("________      ")
          print("|      |      ")
          print("|      0      ")
          print("|     /|\     ")
          print("|             ")
          print("|             ")
          print("Word: ", hidden_string)
        if a == 1:
          print("________      ")
          print("|      |      ")
          print("|      0      ")
          print("|     /|\     ")
          print("|     /       ")
          print("|             ")
          print("Word: ", hidden_string)
          #This code is the display for the different levels of failure the player can get before losing.
        if a == 0:
          print("________      ")
          print("|      |      ")
          print("|      0      ")
          print("|     /|\     ")
          print("|     / \     ")
          print("|             ")
          print("Game Over.\nYou Lose Nerd!!, gg, wp.\nThe word was", lower_word)
          print("   *******   **       **                   **")
          print("  **/////** /**      /**                  /**")
          print(" **     //**/**  **  /**      **   **     /**")
          print("/**      /**/** **   /****** /**  /**  ******")
          print("/**      /**/****    /**///**/**  /** **///**")
          print("//**     ** /**/**   /**  /**/**  /**/**  /**")
          print(" //*******  /**//**  /****** //******//******")
          print("  ///////   //  //   /////    //////  ////// ")
          break
          #Above code is the lose screen when the player runs out of lives
    dmitri.close()
  Hangman(dmitri,my_word)

  r = input("Would you Like to play again ['yes' or 'no']?: ")
  if r == "yes":
    play = 0
  elif r == "Yes":
    play = 0
  else:
    play = 1
    print("Wow...really?, all this work and you dont want another game??, cant believe you rn.")
    #This code is to verify if the player wants another game.
  